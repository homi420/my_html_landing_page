burger=document.querySelector(".burger");
navbar=document.querySelector(".navbar");
navlist=document.querySelector(".ul-nav");
anchor=document.querySelector(".anchor-nav");
logo=document.querySelector(".logo");

burger.addEventListener("click", ()=>
{
    navbar.classList.toggle("h-nav");
    navlist.classList.toggle("v-nav")
})

 project1=document.querySelector("#project1");
 project2=document.querySelector("#project2");
 project3=document.querySelector("#project3");
 project4=document.querySelector("#project4");
 project5=document.querySelector("#project5");
 project6=document.querySelector("#project6");
 content=document.querySelector(".content-heading")

 project1.addEventListener("mouseover",()=>{
content.classList.toggle("hide")
 })

 project2.addEventListener("mouseover",()=>{
    content.classList.toggle("hide")
     })

     project3.addEventListener("mouseover",()=>{
        content.classList.toggle("hide")
         })

         project4.addEventListener("mouseover",()=>{
            content.classList.toggle("hide")
             })

             project5.addEventListener("mouseover",()=>{
                content.classList.toggle("hide")
                 })

                 project6.addEventListener("mouseover",()=>{
                    content.classList.toggle("hide")
                     })




























